//
//  ViewController.swift
//  312PantryStarter
//
//  Created by Leona  Meharenna on 10/31/21.
//

import UIKit

class MapVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


